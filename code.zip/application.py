from flask import Flask, render_template, request
import datetime
import os
import re
import sys
application = app = Flask(__name__)
@app.route('/',methods=['GET','POST'])
def send():
    if request.method == 'POST':
        inputfile = request.files['filename']
        f2=inputfile.filename
        inputfile.save(f2)
        f1=open(f2,"r")
        os.remove(f2)
        tpair=[]                                        #This list combine Hours and Minutes
        backup=""
        lenthback=0
        foundit=0
        for lines in f1:                                #read lines from the file
            ans= re.search("^Time.*og.*$", lines)
            if ans:
                foundit=1
            if foundit==1:
                datecon = re.split(":",lines)
                for plase in datecon:                       #access the list
                    try:
                        if (plase[2]=="p" or plase[2]=="P"):
                            mini=plase[0]+plase[1]
                            shr=backup[lenthback-2]+backup[lenthback-1]
                            hr=int(shr)
                            hrs=12+hr
                            if (hrs==24):
                                hrs=12
                            tpair.append(str(hrs)+":"+str(mini))
                        elif (plase[2]=="a" or plase[2]=="A"):             
                            mini=plase[0]+plase[1]
                            shr=backup[lenthback-2]+backup[lenthback-1]
                            hrs=int(shr)
                            if (hrs==12):
                                hrs=00
                            tpair.append(str(hrs)+":"+str(mini))
                        else:
                            pass
                    except:
                        pass
                    backup=plase                               #For previous element
                    lenthback=len(backup)
            else:
                continue   
        sum = 0
        for subt in range(0,len(tpair),2):                 #All calculation with 24-hours time
            starttime= tpair[subt]
            endtime= tpair[subt+1]
            sdate = datetime.datetime.strptime(starttime, '%H:%M')
            edate = datetime.datetime.strptime(endtime, '%H:%M')
            diff = (edate - sdate)                     #difference of starting time and ending time
            TotalTime = diff.seconds
            sum=sum+TotalTime
            sum1=sum/3600
            sumh=int(sum1)
            summi=int((sum/60)%60)
        return render_template('output.html',dt="Total: "+str(sumh)+" hours "+str(summi)+" minutes.")
    else:
        return render_template('try.html')

if __name__ == '__main__':
    app.run(debug=True)